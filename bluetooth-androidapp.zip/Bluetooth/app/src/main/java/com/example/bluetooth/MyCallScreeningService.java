 package com.example.bluetooth;
 import android.content.ContentResolver;
 import android.content.Context;
 import android.content.Intent;
 import android.database.Cursor;
 import android.net.Uri;
 import android.provider.ContactsContract;
 import android.telecom.CallScreeningService;
 import android.telecom.Call.Details;
 import android.util.Log;

 import org.json.JSONObject;

 public class MyCallScreeningService extends CallScreeningService {


  @Override
  public void onScreenCall(Details callDetails) {
             String incomingNumber = callDetails.getHandle() != null
             ? callDetails.getHandle().getSchemeSpecificPart()
             : "Unknown";

             String contactName = getContactName(getApplicationContext(), incomingNumber);

             Log.d("CallScreening", "Incoming call from: " + incomingNumber + " (" + contactName + ")");

             // Send broadcast
//             Intent intent = new Intent("com.example.CALL_INFO");
//             intent.putExtra("number", incomingNumber);
//             intent.putExtra("contact_name", contactName);
//            getApplicationContext().sendBroadcast(intent);

   try {
       JSONObject callObject=new JSONObject();
       JSONObject callData = new JSONObject();
    callData.put("number", incomingNumber);
    callData.put("contact_name", contactName);
    callData.put("category", "call");

    callObject.put("type","CALLING");
    callObject.put("callData",callData);

    Intent intent = new Intent("com.example.CALL_INFO");
    intent.putExtra("CALLING", callObject.toString());

    Log.d("Broadcast", "Sending CALL_INFO broadcast with data: " + callObject.toString());

    getApplicationContext().sendBroadcast(intent);
   } catch (Exception e) {
    Log.e("error", "Error sending CALL_INFO broadcast", e);
   }

  }

      private String getContactName(Context context, String phoneNumber) {
        ContentResolver cr = context.getContentResolver();
        Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phoneNumber));
        Cursor cursor = cr.query(uri,
           new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME},
  null, null, null);

        if (cursor != null) {
        if (cursor.moveToFirst()) {
        String name = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.PhoneLookup.DISPLAY_NAME));
        cursor.close();
        return name;
        }
        cursor.close();
       }
       return "Unknown";
 }

 }
