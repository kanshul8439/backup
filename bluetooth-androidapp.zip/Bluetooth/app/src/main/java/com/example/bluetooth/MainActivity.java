package com.example.bluetooth;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telecom.TelecomManager;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.Manifest;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import android.content.Intent;


public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_CODE = 101;
    private static final int REQUEST_NOTIFICATION_PERMISSION = 1;
    private BluetoothHandler bluetoothHandler;
    private ContactHandler contactHandler;
    // Only include what you actually use
    private static final String[] REQUIRED_PERMISSIONS = new String[] {
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.MANAGE_OWN_CALLS,
            Manifest.permission.CALL_PHONE,
    };
    private EditText notificationType;
    private EditText notificationBody;
    private EditText notificationTime;
    private EditText notificationInfo;
    private Button sendButton;
    NotificationLoggerService notificationLoggerService;
    MyCallScreeningService myCallScreeningService;

    private final  BroadcastReceiver notificationReceiver=new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d("notification-received","This is the final notification being recieved");
            if ("com.example.NOTIFICATION_LISTENER".equals(intent.getAction())) {
                Log.d("mial","mial");
                String jsonData = intent.getStringExtra("notification_data");
                try {
                    JSONObject data = new JSONObject(jsonData); // Parse back to JSON
//                    String title = data.getString("title");
//                    String text = data.getString("time");
//                    String type = data.getString("type");

                    Log.d("data json", "Notification JSON Received:");
                    Log.d("Data received", data.toString(2)); // Pretty print JSON
                    // You can use this JSON object as needed

                    bluetoothHandler.sendData(data);

                } catch (Exception e) {
                    Log.e("Error parsing", "Error parsing JSON from broadcast", e);
                }
            }
            else if ("com.example.CALL_INFO".equals(intent.getAction())) {
                String jsonData = intent.getStringExtra("CALLING");
                try {
                    JSONObject data = new JSONObject(jsonData); // Parse back to JSON
//                    String number = data.getString("number");
//                    String contactName = data.getString("contact_name");

                    Log.d("Call JSON", "Call Info JSON Received:");
                    Log.d("Data received", data.toString(2)); // Pretty print JSON

                    // You can use this JSON object as needed
                    bluetoothHandler.sendData(data);

                } catch (Exception e) {
                    Log.e("Error parsing", "Error parsing call JSON from broadcast", e);
                }

            }
            }
    };

    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        IntentFilter filter = new IntentFilter();
        filter.addAction("com.example.NOTIFICATION_LISTENER");
        filter.addAction("com.example.CALL_INFO");
        registerReceiver(notificationReceiver, filter);

        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);

        setContentView(R.layout.activity_main);

        requestDefaultDialer();
        startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));

        checkAndRequestPermissions();

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE}, 1);
        }


        // Initialize UI elements
        notificationType = findViewById(R.id.notification_type);
        notificationBody = findViewById(R.id.notification_body);
        notificationTime = findViewById(R.id.notification_time);
        notificationInfo = findViewById(R.id.notification_info);
        sendButton = findViewById(R.id.send_button);

        sendButton.setOnClickListener(v -> sendNotification());


    }


private void checkAndRequestPermissions() {
        List<String> missingPermissions = new ArrayList<>();

        for (String permission : REQUIRED_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                missingPermissions.add(permission);
            }
        }

        if (!missingPermissions.isEmpty()) {
            ActivityCompat.requestPermissions(
                    this,
                    missingPermissions.toArray(new String[0]),
                    PERMISSION_REQUEST_CODE
            );
        } else {
            initHandlers(); // All permissions granted
        }
    }
    private void requestNotificationPermission() {

            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        REQUEST_NOTIFICATION_PERMISSION);
            }
    }
    public void requestDefaultDialer() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            TelecomManager telecomManager = (TelecomManager) getSystemService(TELECOM_SERVICE);
            String packageName = getPackageName();
            if (!packageName.equals(telecomManager.getDefaultDialerPackage())) {
                Intent intent = new Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER);
                intent.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName);
                startActivity(intent);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }

            if (allGranted) {
                initHandlers();
                requestDefaultDialer();
            } else {
                Toast.makeText(this, "Some permissions were denied. App functionality may be limited.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void initHandlers() {
        contactHandler = new ContactHandler(this);
        bluetoothHandler = new BluetoothHandler(this);

        contactHandler.loadContacts();
        contactHandler.loadCallLogs();

        bluetoothHandler.connect();

        bluetoothHandler.sendData(contactHandler.getContactsAsJson());
        bluetoothHandler.sendData(contactHandler.getCallLogsAsJson());

    }


    private void sendNotification() {
        String type = notificationType.getText().toString();
        String body = notificationBody.getText().toString();
        String time = notificationTime.getText().toString();
        String info = notificationInfo.getText().toString();

        String notificationData = "Type: " + type + "\nBody: " + body + "\nTime: " + time + "\nInfo: " + info;
        LocalTime currentTime = LocalTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
        String formattedTime = currentTime.format(formatter);

        try {
            JSONObject notificationArray = new JSONObject();
            JSONObject root = new JSONObject();

            notificationArray.put("type",type);
            notificationArray.put("title",body);
            notificationArray.put("text",formattedTime);

            root.put("type","NOTIFICATION");
            root.put("NOTIFICATION", notificationArray);

            bluetoothHandler.sendData(root);
        } catch (JSONException e) {
            Log.e("ContactHandler", "Error creating JSON: " + e.getMessage());
        }
        Log.d("notificationData", notificationData);
    }

}


