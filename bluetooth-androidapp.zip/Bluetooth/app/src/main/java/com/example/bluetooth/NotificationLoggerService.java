package com.example.bluetooth;

import android.app.Notification;
import android.content.Intent;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Set;

public class NotificationLoggerService extends NotificationListenerService {
    private static final String TAG = "NotificationLogger";
    private static final Set<Integer> sentNotifications = new HashSet<>();

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        Log.d(TAG, "Notification received");

        String packageName = sbn.getPackageName();
        Notification notification = sbn.getNotification();
        Bundle extras = notification.extras;

        CharSequence title = extras.getCharSequence("android.title");
        CharSequence text = extras.getCharSequence("android.text");

        // Skip ongoing or foreground service notifications
        if ((notification.flags & Notification.FLAG_ONGOING_EVENT) != 0 ||
                (notification.flags & Notification.FLAG_FOREGROUND_SERVICE) != 0) {
            return;
        }

        // Allowlist of packages
        List<String> allowedPackages = Arrays.asList(
                "com.whatsapp",
                "com.google.android.apps.messaging",
                "com.android.messaging",
                "com.samsung.android.messaging"
        );

        // Filter by package and content
        if (!allowedPackages.contains(packageName)) {
            if (text == null || text.toString().trim().isEmpty()) {
                return;
            }
        }

        // Optional: filter by category
        String category = notification.category;
        if (category != null && !(category.equals(Notification.CATEGORY_MESSAGE) ||
                category.equals(Notification.CATEGORY_CALL))) {
            if (!packageName.equals("com.whatsapp") && (text == null || text.length() < 2)) {
                return;
            }
        }
        // Debug: log extras for phone notifications
        //        if (packageName.equals("com.android.phone")) {
        //            for (String key : extras.keySet()) {
        //                Object value = extras.get(key);
        //                Log.d("NotificationExtras", key + " => " + value);
        //            }
        //        }

        // Create a unique hash for the notification
        int notificationHash = Objects.hash(packageName,
                title != null ? title.toString() : "",
                text != null ? text.toString() : "");

        // Check for duplicates
        if (sentNotifications.contains(notificationHash)) {
            Log.d(TAG, "Duplicate notification skipped.");
            return;
        }

        // Add to the set
        sentNotifications.add(notificationHash);

        // Trim the set to avoid memory issues
        if (sentNotifications.size() > 100) {
            Iterator<Integer> iterator = sentNotifications.iterator();
            if (iterator.hasNext()) {
                iterator.next();
                iterator.remove();
            }
        }
        // Prepare and send broadcast
        try {
            JSONObject notificationObject = new JSONObject();
            JSONObject notificationData=new JSONObject();

            notificationData.put("type", packageName);
            notificationData.put("title", title);
            notificationData.put("text", text);

            notificationObject.put("type","NOTIFICATION");
            notificationObject.put("NOTIFICATION",notificationData);

            Intent intent = new Intent("com.example.NOTIFICATION_LISTENER");
            intent.putExtra("notification_data", notificationObject.toString());

            Log.d("Broadcast", "Sending broadcast with data: " + notificationObject.toString());

            getApplicationContext().sendBroadcast(intent);

        } catch (Exception e) {
            Log.e(TAG, "Error sending broadcast", e);
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        Log.d(TAG, "Notification removed: " + sbn.getPackageName());
    }
}
