package com.example.bluetooth;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.util.Log;

import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import java.util.List;
import android.Manifest;

public class ContactHandler {

    private Context context;
    private List<Contact> contactList = new ArrayList<>();
    private List<RecentCallLog> callLogList=new ArrayList<>();
    public ContactHandler(Context context) {
        this.context = context;
    }

    // Fetch all contacts and their phone numbers
    void loadContacts(){
        contactList.clear();
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
                == PackageManager.PERMISSION_GRANTED) {
            ContentResolver contentResolver = context.getContentResolver();
            Cursor cursor = contentResolver.query(ContactsContract.Contacts.CONTENT_URI,
                    null, null, null, null);

            if (cursor != null && cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    @SuppressLint("Range") String contactName = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                    @SuppressLint("Range") String contactId = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));

                    // Fetch phone number for this contact
                    Cursor phoneCursor = contentResolver.query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                            new String[]{contactId},
                            null
                    );
                    if (phoneCursor != null && phoneCursor.moveToNext()) {
                        @SuppressLint("Range") String phoneNumber = phoneCursor.getString(phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));

                        // Add contact info to list
                        this.contactList.add(new Contact(contactName, phoneNumber));
                        phoneCursor.close();
                    }
                }
                cursor.close();
            }
        } else {
            Log.e("ContactHandler", "Permission not granted to read contacts.");
        }

    }
    public List<Contact> getContacts() {
        return contactList;
    }
    @SuppressLint("Range")
    void loadCallLogs(){
        callLogList.clear();
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALL_LOG)
                == PackageManager.PERMISSION_GRANTED) {
            ContentResolver contentResolver = context.getContentResolver();
            int logcount=0;
            Cursor callLogCursor = contentResolver.query(CallLog.Calls.CONTENT_URI,
                    null, null, null,
                    CallLog.Calls.DATE + " DESC" // Sort by most recent
            );

            if (callLogCursor != null) {
                while ((logcount < 30) && callLogCursor.moveToNext()) {
                    String phoneNumber;
                    phoneNumber = callLogCursor.getString(callLogCursor.getColumnIndex(CallLog.Calls.NUMBER));

                    int callTypeCode;
                    callTypeCode = callLogCursor.getInt(callLogCursor.getColumnIndex(CallLog.Calls.TYPE));
                    CallType callType = CallType.fromCode(callTypeCode);



                    String callDate = callLogCursor.getString(callLogCursor.getColumnIndex(CallLog.Calls.DATE));
                    Instant instant = Instant.ofEpochMilli(Long.parseLong(callDate));

                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("H:mm, d MMM").withZone(ZoneId.systemDefault());

                    String formattedDateTime = formatter.format(instant);



                    String durationStr = callLogCursor.getString(callLogCursor.getColumnIndex(CallLog.Calls.DURATION));
                    long durationInSeconds = Long.parseLong(durationStr);

                    long minutes = durationInSeconds / 60;
                    long seconds = durationInSeconds % 60;

                    String formattedDuration = String.format("%d min %d sec", minutes, seconds);


                    String cachedName=callLogCursor.getString(callLogCursor.getColumnIndex(CallLog.Calls.CACHED_NAME));
                    if (cachedName == null) {
                        // Not saved in contacts
                        cachedName="Unknown";
                    } else if (!isContactSavedLocally(context,cachedName)) {
                        // Possibly caller ID or external info
                        cachedName="Unknown";
                    } else {
                        // Known contact valid cachedName
                    }


                    logcount++;
                    this.callLogList.add(new RecentCallLog(phoneNumber, callType.getLabel(),formattedDateTime, cachedName,formattedDuration));
//                Log.d("number ",phoneNumber);
//                Log.d("calltype ",callType.getLabel());
//                Log.d("calldate ",formattedDateTime);
//                Log.d("Name ",cachedName);
//                Log.d("duration",formattedDuration);
//                Log.d("sep","--------");

                }
                callLogCursor.close();
            }
        }else {
            Log.d("callperm","permission denied actually");
        }

    }

    public List<RecentCallLog> getCallLogs() {
        return callLogList;
    }
    public boolean isContactSavedLocally(Context context, String name) {
        Cursor cursor = context.getContentResolver().query(
                ContactsContract.Contacts.CONTENT_URI,
                null,
                ContactsContract.Contacts.DISPLAY_NAME + " = ?",
                new String[]{name},
                null
        );

        boolean exists = (cursor != null && cursor.getCount() > 0);
        if (cursor != null) {
            cursor.close();
        }
        return exists;
    }

    public JSONObject getCallLogsAsJson() {

        JSONObject callLogsJson = new JSONObject();
        JSONArray callLogArray = new JSONArray();
        List<RecentCallLog> callLogs=getCallLogs();

        try {
            for (RecentCallLog callLog : callLogs) {

                JSONObject callLogJson = new JSONObject();
                callLogJson.put("Number", callLog.getNumber());
                callLogJson.put("CallType", callLog.getType()); // Add phone number
                callLogJson.put("Date",callLog.getCallDate());
                callLogJson.put("Name",callLog.getName());
                callLogJson.put("CallDuration",callLog.getDuration());

                callLogArray.put(callLogJson);
            }
            callLogsJson.put("type","RECENT_CALLS");
            callLogsJson.put("recent_calls", callLogArray);
            Log.d("call logs",callLogsJson.toString());
        } catch (JSONException e) {
            Log.e("ContactHandler", "Error creating JSON: " + e.getMessage());
        }
        return callLogsJson;
    }


    // Convert the contact list into a JSON object
    public JSONObject getContactsAsJson() {
        List<Contact> contacts =getContacts();
        JSONObject contactsJson = new JSONObject();
        JSONArray contactsArray = new JSONArray();

        try {
            for (Contact contact : contacts) {
                JSONObject contactJson = new JSONObject();
                contactJson.put("name", contact.getName());
                contactJson.put("phone", contact.getPhoneNumber()); // Add phone number
                contactsArray.put(contactJson);
            }
            contactsJson.put("type","CONTACTS");
            contactsJson.put("contacts", contactsArray);
        } catch (JSONException e) {
            Log.e("ContactHandler", "Error creating JSON: " + e.getMessage());
        }

        return contactsJson;
    }

}