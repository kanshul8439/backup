package com.example.bluetooth;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.util.Log;

import org.json.JSONObject;


import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.UUID;

public class BluetoothHandler {

    // Static MAC address of the Bluetooth device
    private static final String DEVICE_ADDRESS = "D4:54:8B:62:F3:E4"; // Replace with actual MAC address
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"); // Standard SerialPortService ID

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket bluetoothSocket;
    private BluetoothDevice bluetoothDevice;

    public BluetoothHandler(Context context) {
        // Get BluetoothAdapter through BluetoothManager for Android 13+
        BluetoothManager bluetoothManager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
        if (bluetoothManager != null) {
            bluetoothAdapter = bluetoothManager.getAdapter();
        }

        if (bluetoothAdapter == null) {
            Log.e("BluetoothHandler", "Bluetooth is not supported on this device.");
        }
    }

    // Method to initiate connection to the Bluetooth device
    public boolean connect() {
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) {
            Log.e("BluetoothHandler", "Bluetooth is not enabled.");
            return false;
        }

        for (BluetoothDevice pairedDevice : bluetoothAdapter.getBondedDevices()) {
            Log.d("Bluetooth", "Paired Device:- " + pairedDevice.getName() + " | " + pairedDevice.getAddress());
        }

        // Get Bluetooth device by MAC address
        bluetoothDevice = bluetoothAdapter.getRemoteDevice(DEVICE_ADDRESS);

        try {
            // Create a BluetoothSocket using reflection to ensure compatibility
            Method method = bluetoothDevice.getClass().getMethod("createInsecureRfcommSocket", int.class);
//            bluetoothSocket = (BluetoothSocket) method.invoke(bluetoothDevice, 1);
            bluetoothSocket=bluetoothDevice.createRfcommSocketToServiceRecord(MY_UUID);
            Log.d("devicename", bluetoothDevice.getName());

            // Connect to the remote device
            bluetoothSocket.connect();
            Log.d("BluetoothHandler", "Successfully connected to device: " + DEVICE_ADDRESS);

            // 🔍 Check if connected properly
            if (bluetoothSocket.isConnected()) {
                Log.d("BluetoothHandler", "RFCOMM connection established!");

                // ** Start a background thread to listen for incoming data **
                listenForData();
                return true;
            } else {
                Log.e("BluetoothHandler", "Socket shows connected but not properly bound.");
                return false;
            }

        } catch (Exception e) {
            Log.e("BluetoothHandler", "Failed to connect: " + e.getMessage());
            return false;
        }
    }

    // Method to send data over Bluetooth
    public void sendData(JSONObject data) {
        if (bluetoothSocket == null || !bluetoothSocket.isConnected()) {
            Log.e("BluetoothHandler", "Not connected to any device.");
            return;
        }

        try {
            // Get output stream for sending data
            OutputStream outputStream = bluetoothSocket.getOutputStream();

            // Convert the data to bytes (e.g., JSON object to String and then to bytes)
            String dataString = data.toString();
            String finalString=dataString+"\n";
            byte[] dataBytes = finalString.getBytes();

            // Send the data
            outputStream.write(dataBytes);
            outputStream.flush();
            Log.d("data string",dataString);
            Log.d("BluetoothHandler", "Data sent successfully.");

        } catch (IOException e) {
            Log.e("BluetoothHandler", "Failed to send data: " + e.getMessage());
        }
    }

    // Method to listen for incoming data
    private void listenForData() {
        new Thread(() -> {
            try {
                InputStream inputStream = bluetoothSocket.getInputStream();
                byte[] buffer = new byte[1024];
                int bytes;

                while (bluetoothSocket.isConnected()) {
                    bytes = inputStream.read(buffer);
                    if (bytes > 0) {
                        String receivedData = new String(buffer, 0, bytes);
                        Log.d("BluetoothHandler", "Received Data: " + receivedData);
                    }
                }
            } catch (IOException e) {
                Log.e("BluetoothHandler", "Failed to read data: " + e.getMessage());
            }
        }).start();
    }

    // Disconnect the Bluetooth connection
    public void disconnect() {
        if (bluetoothSocket != null) {
            try {
                bluetoothSocket.close();
                Log.d("BluetoothHandler", "Disconnected successfully.");
            } catch (IOException e) {
                Log.e("BluetoothHandler", "Failed to disconnect: " + e.getMessage());
            }
        }
    }
}