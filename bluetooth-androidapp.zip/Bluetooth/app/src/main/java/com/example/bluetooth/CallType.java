package com.example.bluetooth;

import android.provider.CallLog;

public enum CallType {
    INCOMING(CallLog.Calls.INCOMING_TYPE, "Incoming"),
    OUTGOING(CallLog.Calls.OUTGOING_TYPE, "Outgoing"),
    MISSED(CallLog.Calls.MISSED_TYPE, "Missed"),
    VOICEMAIL(CallLog.Calls.VOICEMAIL_TYPE, "Voicemail"),
    REJECTED(CallLog.Calls.REJECTED_TYPE, "Rejected"),
    BLOCKED(CallLog.Calls.BLOCKED_TYPE, "Blocked"),
    ANSWERED_EXTERNALLY(CallLog.Calls.ANSWERED_EXTERNALLY_TYPE, "ExtAnswer"),
    UNKNOWN(-1, "Unknown");

    private final int code;
    private final String label;

    CallType(int code, String label) {
        this.code = code;
        this.label = label;
    }

    public static CallType fromCode(int code) {
        for (CallType type : CallType.values()) {
            if (type.code == code) {
                return type;
            }
        }
        return UNKNOWN;
    }

    public String getLabel() {
        return label;
    }
}

