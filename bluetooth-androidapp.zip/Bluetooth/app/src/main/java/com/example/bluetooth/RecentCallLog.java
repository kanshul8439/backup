package com.example.bluetooth;

public class RecentCallLog{
    private String Number;
    private String Type;
    private String CallDate;
    private String Name;

    private  String Duration;
    public RecentCallLog(String Number, String Type,String CallDate,String Name,String Duration) {
        this.CallDate=CallDate;
        this.Name=Name;
        this.Number=Number;
        this.Type=Type;
        this.Duration=Duration;
    }
    public String getNumber() {
        return Number;
    }
    public String getType() {
        return Type;
    }
    public String getCallDate() {
     return CallDate;
    }
    public String getName() {
     return Name;
    }
    public String getDuration(){
        return Duration;
    }
}